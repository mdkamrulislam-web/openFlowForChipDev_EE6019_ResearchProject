/*
 * Copyright (c) 2026 MD. KAMRUL ISLAM
 * SPDX-License-Identifier: Apache-2.0
 */

`default_nettype none

module tt_um_mdkamrulislam_counter (
    input  wire [7:0] ui_in,    // Dedicated inputs
    output wire [7:0] uo_out,   // Dedicated outputs
    input  wire [7:0] uio_in,   // IOs: Input path
    output wire [7:0] uio_out,  // IOs: Output path
    output wire [7:0] uio_oe,   // IOs: Enable path (active high: 0=input, 1=output)
    input  wire       ena,      // always 1 when the design is powered, so you can ignore it
    input  wire       clk,      // clock
    input  wire       rst_n     // reset_n - low to reset
);

  // All output pins must be assigned. If not used, assign to 0.
  counter #(.WIDTH(8)) counter_inst (
      .clk(clk), .rst(~rst_n), .en(ui_in[0]),
      .count(uo_out), .wrap(uio_out[0])
  );
  assign uio_out[7:1] = 7'b0;
  assign uio_oe = 8'b0000_0001;

  // List all unused inputs to prevent warnings
  wire _unused = &{ena, ui_in[7:1], uio_in, 1'b0};

endmodule

`default_nettype wire
